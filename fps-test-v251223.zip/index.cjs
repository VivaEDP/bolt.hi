(function(global, factory) {
  typeof exports === "object" && typeof module !== "undefined" ? factory(exports, require("node:fs")) : typeof define === "function" && define.amd ? define(["exports", "node:fs"], factory) : (global = typeof globalThis !== "undefined" ? globalThis : global || self, factory(global.FpsTest = {}, global.node_fs));
})(this, (function(exports2, node_fs) {
  "use strict";
  const business_service = ["PAYC01", "PAYC02", "PAYD01"];
  var FpsService = /* @__PURE__ */ ((FpsService2) => {
    FpsService2[FpsService2["PAYC01"] = 0] = "PAYC01";
    FpsService2[FpsService2["PAYC02"] = 1] = "PAYC02";
    FpsService2[FpsService2["PAYC03"] = 2] = "PAYC03";
    FpsService2[FpsService2["PAYD01"] = 3] = "PAYD01";
    return FpsService2;
  })(FpsService || {});
  var FpsMessageType = /* @__PURE__ */ ((FpsMessageType2) => {
    FpsMessageType2["OUTWARD_REQUEST"] = "OUTWARD_REQUEST";
    FpsMessageType2["OUTWARD_RERESPONSE"] = "OUTWARD_RERESPONSE";
    FpsMessageType2["INWARD_REQUEST"] = "INWARD_REQUEST";
    return FpsMessageType2;
  })(FpsMessageType || {});
  const FPS_SERVICE_C01_MESSAGE_TYPE_MAP = /* @__PURE__ */ new Map([
    ["OUTWARD_REQUEST", "fxtr.008.001.08"],
    ["INWARD_REQUEST", "fxtr.017.001.06"]
  ]);
  const FPS_SERVICE_MESSAGE_MAP = /* @__PURE__ */ new Map([
    [0, FPS_SERVICE_C01_MESSAGE_TYPE_MAP],
    [3, FPS_SERVICE_C01_MESSAGE_TYPE_MAP]
  ]);
  const female_name = [
    "Charlotte",
    "Natalie",
    "Michelle",
    "Kelly",
    "Catherine",
    "Hailey",
    "Nicole",
    "Emily",
    "Mandy",
    "Chloe",
    "Kate",
    "Iris",
    "Angel",
    "Lily",
    "Anna",
    "Cherry",
    "Rain",
    "Athena",
    "Christine",
    "Noel",
    "Audrey",
    "Jade",
    "Annie",
    "Heidi",
    "Janet",
    "Ariel",
    "Yan",
    "Melissa",
    "Alice",
    "Karen",
    "Jennifer",
    "Zoe",
    "Cleo",
    "Sarah",
    "Yumi",
    "Eunice",
    "Abigail",
    "Priscilla",
    "Agnes",
    "Stacy",
    "Coco",
    "Evelyn",
    "Sandy",
    "Carly",
    "KiKi",
    "Yuki",
    "Jenny",
    "Celia",
    "Christy",
    "Wendy",
    "Cathy",
    "Inez",
    "Carmen",
    "Amber",
    "Kitty",
    "Alison",
    "Bella",
    "Amelia",
    "Ann",
    "Tracy",
    "Joey",
    "Janice",
    "Suki",
    "Candy",
    "Bernice",
    "Crystal",
    "Jasmine",
    "Rachel",
    "Kezia",
    "Stella",
    "Andree",
    "Ring",
    "Sierra",
    "Katie",
    "Melis",
    "Trevina",
    "Arishaaa",
    "Amy",
    "Jamie",
    "Laura",
    "Charlene",
    "Herma",
    "Jaime"
  ];
  const male_name = [
    "Jason",
    "Lucas",
    "kenneth",
    "Ryan",
    "Jay",
    "Vincent",
    "Owen",
    "Eric",
    "Marco",
    "Matthew",
    "Roy",
    "Chase",
    "Jamie",
    "Samuel",
    "Renaud",
    "Jack",
    "Tom",
    "Kyle",
    "Thomas",
    "Jerry",
    "John",
    "Fita",
    "Jacky",
    "Sage",
    "Jonathan",
    "Trevor",
    "Chin",
    "Anthony",
    "Bowie",
    "Cora",
    "William",
    "Jeffrey",
    "Hans",
    "Ian",
    "Duncan",
    "Dylan",
    "Kyrie",
    "James",
    "Austin",
    "Bikas",
    "Bruce",
    "Simon",
    "Marcus",
    "Ringo",
    "Aria",
    "Jim",
    "Camille",
    "Yannick",
    "Nathaniel",
    "Zach",
    "Joshua",
    "Howard",
    "Horis",
    "Archibald",
    "Oscar",
    "Hon",
    "Louis",
    "Kendrick",
    "Seol",
    "Carlos",
    "Timmy",
    "Anson",
    "Andrew",
    "Kevin",
    "Edwin",
    "Ken",
    "Henry",
    "Eddy",
    "Abel"
  ];
  const surname = [
    "Wang",
    "Li",
    "Zhang",
    "Liu",
    "Chen",
    "Yang",
    "Huang",
    "Zhao",
    "Zhou",
    "Wu"
  ];
  const female_name_zh = [
    "卿",
    "嬌",
    "蓮",
    "珍",
    "玲",
    "思",
    "彤",
    "軒",
    "琪",
    "欣"
  ];
  const male_name_zh = ["豪", "偉", "泉", "緯", "強", "輝", "傑", "彥", "諾"];
  const surname_zh = ["王", "李", "张", "刘", "陳", "杨", "黄", "赵", "周", "吴"];
  const fps = {
    business_service
  };
  const person = {
    female_name,
    male_name,
    surname,
    female_name_zh,
    male_name_zh,
    surname_zh
  };
  class JsonToXmlConverter {
    options;
    constructor(options = {}) {
      this.options = {
        attributePrefix: options.attributePrefix ?? "@",
        textKey: options.textKey ?? "#text",
        rootElement: options.rootElement ?? "root",
        declaration: options.declaration ?? true,
        indent: options.indent ?? "  "
      };
    }
    convert(jsonData, rootElement) {
      let xml = "";
      if (this.options.declaration) {
        xml += '<?xml version="1.0" encoding="UTF-8"?>\n';
      }
      const root = rootElement || this.options.rootElement;
      xml += this.objectToXml(jsonData, root, 0);
      return xml;
    }
    objectToXml(obj, elementName, depth) {
      const indent = this.options.indent.repeat(depth);
      if (this.isPrimitive(obj)) {
        return `${indent}<${elementName}>${this.escapeXml(String(obj))}</${elementName}>
`;
      }
      if (Array.isArray(obj)) {
        return this.arrayToXml(obj, elementName, depth);
      }
      return this.complexObjectToXml(obj, elementName, depth);
    }
    arrayToXml(array, elementName, depth) {
      let xml = "";
      for (const item of array) {
        xml += this.objectToXml(item, elementName, depth);
      }
      return xml;
    }
    complexObjectToXml(obj, elementName, depth) {
      const indent = this.options.indent.repeat(depth);
      const elementInfo = this.processObjectProperties(obj, depth);
      let xml = `${indent}<${elementName}${elementInfo.attributes}>`;
      return this.addElementContent(xml, elementInfo, elementName, indent);
    }
    processObjectProperties(obj, depth) {
      let attributes = "";
      let textContent = "";
      const childElements = [];
      let hasAttributes = false;
      for (const [key, value] of Object.entries(obj)) {
        if (key.startsWith(this.options.attributePrefix)) {
          const attrName = key.substring(this.options.attributePrefix.length);
          attributes += ` ${attrName}="${this.escapeXml(String(value))}"`;
          hasAttributes = true;
        } else if (key === this.options.textKey) {
          textContent = String(value);
        } else {
          this.addChildElements(value, key, depth, childElements);
        }
      }
      return { attributes, textContent, childElements, hasAttributes };
    }
    addChildElements(value, key, depth, childElements) {
      if (Array.isArray(value)) {
        for (const item of value) {
          childElements.push(this.objectToXml(item, key, depth + 1));
        }
      } else {
        childElements.push(this.objectToXml(value, key, depth + 1));
      }
    }
    addElementContent(xml, elementInfo, elementName, indent) {
      const { textContent, childElements, hasAttributes } = elementInfo;
      const nextIndent = indent + this.options.indent;
      if (textContent && childElements.length === 0) {
        return xml + this.escapeXml(textContent) + `</${elementName}>
`;
      }
      if (childElements.length > 0) {
        xml += "\n";
        if (textContent) {
          xml += `${nextIndent}${this.escapeXml(textContent)}
`;
        }
        for (const childXml of childElements) {
          xml += childXml;
        }
        return xml + `${indent}</${elementName}>
`;
      }
      return hasAttributes ? xml.substring(0, xml.length - 1) + "/>\n" : xml.replace(">", "/>\n");
    }
    isPrimitive(value) {
      return value === null || typeof value === "string" || typeof value === "number" || typeof value === "boolean";
    }
    escapeXml(text) {
      return text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;");
    }
  }
  class XmlParser {
    position = 0;
    line = 1;
    column = 1;
    xml = "";
    parse(xmlString) {
      this.xml = xmlString;
      this.position = 0;
      this.line = 1;
      this.column = 1;
      const errors = [];
      try {
        this.skipWhitespace();
        if (this.peek(0, 5) === "<?xml") {
          this.skipDeclaration();
          this.skipWhitespace();
        }
        while (this.position < this.xml.length && this.current() === "<") {
          if (this.peek() === "!") {
            this.skipComment();
            this.skipWhitespace();
          } else if (this.peek() === "?") {
            this.skipProcessingInstruction();
            this.skipWhitespace();
          } else {
            break;
          }
        }
        const node = this.parseElement();
        return { node, errors };
      } catch (error) {
        errors.push({
          line: this.line,
          column: this.column,
          message: error instanceof Error ? error.message : "Unknown parsing error",
          code: "PARSE_ERROR"
        });
        return { node: null, errors };
      }
    }
    parseElement() {
      if (this.current() !== "<") {
        throw new Error(`Expected '<' but found '${this.current()}'`);
      }
      this.advance();
      if (this.current() === "/") {
        throw new Error("Unexpected end tag");
      }
      const name = this.parseName();
      const attributes = this.parseAttributes();
      this.skipWhitespace();
      if (this.current() === "/" && this.peek() === ">") {
        this.advance();
        this.advance();
        return { name, attributes, children: [] };
      }
      if (this.current() !== ">") {
        throw new Error(`Expected '>' but found '${this.current()}'`);
      }
      this.advance();
      return this.parseElementContent(name, attributes);
    }
    parseElementContent(name, attributes) {
      const children = [];
      let text = "";
      this.skipWhitespace();
      this.skipComment();
      while (this.position < this.xml.length) {
        if (this.current() === "<") {
          if (this.peek() === "/") {
            break;
          } else {
            if (text.trim()) {
              children.push({
                name: "#text",
                attributes: {},
                children: [],
                text: text.trim()
              });
              text = "";
            }
            children.push(this.parseElement());
            continue;
          }
        }
        text += this.current();
        this.advance();
      }
      this.parseEndTag(name);
      return this.buildElementNode(name, attributes, children, text);
    }
    parseEndTag(expectedName) {
      if (this.current() === "<" && this.peek() === "/") {
        this.advance();
        this.advance();
        const endTagName = this.parseName();
        if (endTagName !== expectedName) {
          throw new Error(
            `End tag '${endTagName}' does not match start tag '${expectedName}'`
          );
        }
        this.skipWhitespace();
        if (this.current() !== ">") {
          throw new Error("Expected '>' in end tag");
        }
        this.advance();
      }
    }
    buildElementNode(name, attributes, children, text) {
      const node = { name, attributes, children };
      if (text.trim() && children.length === 0) {
        node.text = text.trim();
      }
      return node;
    }
    parseAttributes() {
      const attributes = {};
      while (this.position < this.xml.length) {
        this.skipWhitespace();
        if (this.current() === ">" || this.current() === "/" || this.current() === "?") {
          break;
        }
        const name = this.parseName();
        this.skipWhitespace();
        if (this.current() !== "=") {
          throw new Error(`Expected '=' after attribute name '${name}'`);
        }
        this.advance();
        this.skipWhitespace();
        const value = this.parseAttributeValue();
        attributes[name] = value;
      }
      return attributes;
    }
    parseAttributeValue() {
      const quote = this.current();
      if (quote !== '"' && quote !== "'") {
        throw new Error(`Expected quote but found '${quote}'`);
      }
      this.advance();
      let value = "";
      while (this.position < this.xml.length && this.current() !== quote) {
        if (this.current() === "&") {
          value += this.parseEntity();
        } else {
          value += this.current();
          this.advance();
        }
      }
      if (this.current() !== quote) {
        throw new Error("Unterminated attribute value");
      }
      this.advance();
      return value;
    }
    parseName() {
      let name = "";
      const firstChar = this.current();
      if (!this.isNameStartChar(firstChar)) {
        throw new Error(`Invalid name start character: '${firstChar}'`);
      }
      while (this.position < this.xml.length) {
        const char = this.current();
        if (this.isNameChar(char)) {
          name += char;
          this.advance();
        } else {
          break;
        }
      }
      if (!name) {
        throw new Error("Expected element name");
      }
      return name;
    }
    isNameStartChar(char) {
      if (!char) return false;
      return /[a-zA-Z_]/.test(char) || char.charCodeAt(0) >= 192 && char.charCodeAt(0) <= 214 || char.charCodeAt(0) >= 216 && char.charCodeAt(0) <= 246 || char.charCodeAt(0) >= 248;
    }
    parseEntity() {
      if (this.current() !== "&") {
        throw new Error("Expected entity");
      }
      this.advance();
      let entity = "";
      while (this.position < this.xml.length && this.current() !== ";") {
        entity += this.current();
        this.advance();
      }
      if (this.current() !== ";") {
        throw new Error("Unterminated entity");
      }
      this.advance();
      switch (entity) {
        case "amp":
          return "&";
        case "lt":
          return "<";
        case "gt":
          return ">";
        case "quot":
          return '"';
        case "apos":
          return "'";
        default:
          if (entity.startsWith("#")) {
            const code = entity.startsWith("#x") ? parseInt(entity.slice(2), 16) : parseInt(entity.slice(1), 10);
            return String.fromCharCode(code);
          }
          return `&${entity};`;
      }
    }
    skipDeclaration() {
      while (this.position < this.xml.length && !(this.current() === "?" && this.peek() === ">")) {
        this.advance();
      }
      if (this.current() === "?") {
        this.advance();
      }
      if (this.current() === ">") {
        this.advance();
      }
    }
    skipComment() {
      if (this.peek(0, 4) === "<!--") {
        this.skipXmlComment();
      } else if (this.peek(0, 9) === "<!DOCTYPE") {
        this.skipDoctype();
      }
    }
    skipXmlComment() {
      this.position += 4;
      while (this.position < this.xml.length - 2) {
        if (this.xml.substring(this.position, this.position + 3) === "-->") {
          this.position += 3;
          break;
        }
        this.advance();
      }
    }
    skipDoctype() {
      let depth = 0;
      while (this.position < this.xml.length) {
        if (this.current() === "<") {
          depth++;
        } else if (this.current() === ">") {
          depth--;
          if (depth === 0) {
            this.advance();
            break;
          }
        }
        this.advance();
      }
    }
    skipProcessingInstruction() {
      while (this.position < this.xml.length - 1) {
        if (this.current() === "?" && this.peek() === ">") {
          this.advance();
          this.advance();
          break;
        }
        this.advance();
      }
    }
    skipWhitespace() {
      while (this.position < this.xml.length && this.isWhitespace(this.current())) {
        this.advance();
      }
    }
    isWhitespace(char) {
      return char === " " || char === "	" || char === "\n" || char === "\r";
    }
    isNameChar(char) {
      if (!char) return false;
      return /[a-zA-Z0-9_:.-]/.test(char) || char.charCodeAt(0) >= 192 && char.charCodeAt(0) <= 214 || char.charCodeAt(0) >= 216 && char.charCodeAt(0) <= 246 || char.charCodeAt(0) >= 248;
    }
    current() {
      return this.xml[this.position] || "";
    }
    peek(offset = 1, length = 1) {
      return length === 1 ? this.xml[this.position + offset] || "" : this.xml.substring(
        this.position + offset,
        this.position + offset + length
      ) || "";
    }
    advance() {
      if (this.position < this.xml.length) {
        if (this.xml[this.position] === "\n") {
          this.line++;
          this.column = 1;
        } else {
          this.column++;
        }
        this.position++;
      }
    }
  }
  class XmlToJsonConverter {
    options;
    constructor(options = {}) {
      this.options = {
        preserveAttributes: options.preserveAttributes ?? true,
        attributePrefix: options.attributePrefix ?? "@",
        textKey: options.textKey ?? "#text",
        ignoreNamespaces: options.ignoreNamespaces ?? false
      };
    }
    convert(xmlNode) {
      return this.nodeToJson(xmlNode);
    }
    nodeToJson(node) {
      const result = {};
      this.options.ignoreNamespaces ? this.getLocalName(node.name) : node.name;
      if (node.text !== void 0 && node.children.length === 0 && Object.keys(node.attributes).length === 0) {
        return this.convertValue(node.text);
      }
      if (this.options.preserveAttributes && Object.keys(node.attributes).length > 0) {
        for (const [key, value] of Object.entries(node.attributes)) {
          const attrKey = this.options.ignoreNamespaces ? this.getLocalName(key) : key;
          result[this.options.attributePrefix + attrKey] = this.convertValue(value);
        }
      }
      if (node.text !== void 0) {
        result[this.options.textKey] = this.convertValue(node.text);
      }
      const elementGroups = {};
      for (const child of node.children) {
        if (child.name === "#text") {
          if (child.text !== void 0) {
            result[this.options.textKey] = this.convertValue(child.text);
          }
          continue;
        }
        const childName = this.options.ignoreNamespaces ? this.getLocalName(child.name) : child.name;
        const childValue = this.nodeToJson(child);
        if (!elementGroups[childName]) {
          elementGroups[childName] = [];
        }
        elementGroups[childName].push(childValue);
      }
      for (const [name, values] of Object.entries(elementGroups)) {
        if (values.length === 1) {
          result[name] = values[0];
        } else {
          result[name] = values;
        }
      }
      if (Object.keys(result).length === 1 && result[this.options.textKey] !== void 0) {
        return result[this.options.textKey];
      }
      if (Object.keys(result).length === 0 && node.text !== void 0) {
        return this.convertValue(node.text);
      }
      return result;
    }
    convertValue(value) {
      if (value === "true") return true;
      if (value === "false") return false;
      if (value === "null") return null;
      if (/^-?\d+$/.test(value)) {
        const num = parseInt(value, 10);
        if (num.toString() === value) return num;
      }
      if (/^-?\d*\.?\d+$/.test(value)) {
        const num = parseFloat(value);
        if (!isNaN(num) && num.toString() === value) return num;
      }
      return value;
    }
    getLocalName(name) {
      const colonIndex = name.indexOf(":");
      return colonIndex === -1 ? name : name.substring(colonIndex + 1);
    }
  }
  class XmlValidator {
    schema;
    errors = [];
    constructor(schema) {
      this.schema = schema;
    }
    getLocalType(type) {
      const colonIndex = type.indexOf(":");
      return colonIndex === -1 ? type : type.substring(colonIndex + 1);
    }
    validate(xmlNode) {
      this.errors = [];
      const rootElement = this.schema.elements[xmlNode.name];
      if (!rootElement) {
        this.addError(
          1,
          1,
          `Root element '${xmlNode.name}' not found in schema`,
          "ELEMENT_NOT_FOUND"
        );
        return this.errors;
      }
      this.validateElement(xmlNode, rootElement, 1, 1);
      return this.errors;
    }
    validateElement(xmlNode, xsdElement, line, column) {
      if (xmlNode.name !== xsdElement.name) {
        this.addError(
          line,
          column,
          `Expected element '${xsdElement.name}' but found '${xmlNode.name}'`,
          "ELEMENT_MISMATCH"
        );
        return;
      }
      this.validateAttributes(xmlNode, xsdElement, line, column);
      this.getLocalType(xsdElement.type);
      if (this.isBuiltInType(xsdElement.type)) {
        this.validateSimpleContent(xmlNode, xsdElement, line, column);
      } else if (this.schema.complexTypes[xsdElement.type]) {
        this.validateComplexContent(
          xmlNode,
          this.schema.complexTypes[xsdElement.type],
          line,
          column
        );
      } else if (this.schema.simpleTypes[xsdElement.type]) {
        this.validateSimpleTypeContent(
          xmlNode,
          this.schema.simpleTypes[xsdElement.type],
          line,
          column
        );
      } else if (xsdElement.type.startsWith("#inline-")) {
        this.validateInlineContent(xmlNode, xsdElement, line, column);
      }
    }
    validateAttributes(xmlNode, xsdElement, line, column) {
      const complexType = this.schema.complexTypes[xsdElement.type];
      if (!complexType) return;
      for (const xsdAttr of complexType.attributes) {
        if (xsdAttr.use === "required" && !xmlNode.attributes[xsdAttr.name]) {
          this.addError(
            line,
            column,
            `Required attribute '${xsdAttr.name}' is missing`,
            "MISSING_REQUIRED_ATTRIBUTE"
          );
        }
      }
      for (const [attrName, attrValue] of Object.entries(xmlNode.attributes)) {
        if (attrName === "xmlns") {
          console.warn(
            '[AKAR] proper handle element XML namespace switching by attribute "xmlns".'
          );
          continue;
        }
        const xsdAttr = complexType.attributes.find((a) => a.name === attrName);
        if (!xsdAttr) {
          this.addError(
            line,
            column,
            `Attribute '${attrName}' is not allowed`,
            "UNEXPECTED_ATTRIBUTE"
          );
          continue;
        }
        if (xsdAttr.fixedValue && attrValue !== xsdAttr.fixedValue) {
          this.addError(
            line,
            column,
            `Attribute '${attrName}' must have value '${xsdAttr.fixedValue}'`,
            "FIXED_VALUE_VIOLATION"
          );
        }
        if (!this.validateSimpleValue(attrValue, xsdAttr.type)) {
          this.addError(
            line,
            column,
            `Invalid value '${attrValue}' for attribute '${attrName}' of type '${xsdAttr.type}'`,
            "INVALID_ATTRIBUTE_VALUE"
          );
        }
      }
    }
    validateSimpleContent(xmlNode, xsdElement, line, column) {
      if (xmlNode.children.length > 0 && xmlNode.children.some((child) => child.name !== "#text")) {
        this.addError(
          line,
          column,
          `Element '${xmlNode.name}' should contain simple content but has child elements`,
          "INVALID_CONTENT"
        );
        return;
      }
      const textContent = xmlNode.text || xmlNode.children.find((child) => child.name === "#text")?.text || ".ts";
      if (!this.validateSimpleValue(textContent, xsdElement.type)) {
        this.addError(
          line,
          column,
          `Invalid value '${textContent}' for element '${xmlNode.name}' of type '${xsdElement.type}'`,
          "INVALID_ELEMENT_VALUE"
        );
      }
      if (xsdElement.restrictions) {
        this.validateRestrictions(
          textContent,
          xsdElement.restrictions,
          line,
          column,
          xmlNode.name
        );
      }
    }
    validateSimpleTypeContent(xmlNode, simpleType, line, column) {
      const textContent = xmlNode.text || xmlNode.children.find((child) => child.name === "#text")?.text || "";
      if (!this.validateSimpleValue(textContent, simpleType.baseType)) {
        this.addError(
          line,
          column,
          `Invalid value '${textContent}' for base type '${simpleType.baseType}'`,
          "INVALID_SIMPLE_TYPE_VALUE"
        );
      }
      this.validateRestrictions(
        textContent,
        simpleType.restrictions,
        line,
        column,
        xmlNode.name
      );
    }
    validateComplexContent(xmlNode, complexType, line, column) {
      const childElements = xmlNode.children.filter(
        (child) => child.name !== "#text"
      );
      for (const xsdElement of complexType.elements) {
        const matchingChildren = childElements.filter(
          (child) => child.name === xsdElement.name
        );
        if (matchingChildren.length < xsdElement.minOccurs) {
          this.addError(
            line,
            column,
            `Element '${xsdElement.name}' occurs ${matchingChildren.length} times but minimum is ${xsdElement.minOccurs}`,
            "MIN_OCCURS_VIOLATION"
          );
        }
        if (xsdElement.maxOccurs !== "unbounded" && matchingChildren.length > xsdElement.maxOccurs) {
          this.addError(
            line,
            column,
            `Element '${xsdElement.name}' occurs ${matchingChildren.length} times but maximum is ${xsdElement.maxOccurs}`,
            "MAX_OCCURS_VIOLATION"
          );
        }
        for (const childElement of matchingChildren) {
          this.validateElement(childElement, xsdElement, line, column);
        }
      }
      for (const childElement of childElements) {
        if (!complexType.elements.some((xsdEl) => xsdEl.name === childElement.name)) {
          this.addError(
            line,
            column,
            `Unexpected element '${childElement.name}'`,
            "UNEXPECTED_ELEMENT"
          );
        }
      }
    }
    validateInlineContent(xmlNode, xsdElement, line, column) {
      if (xsdElement.restrictions) {
        const textContent = xmlNode.text || xmlNode.children.find((child) => child.name === "#text")?.text || "";
        this.validateRestrictions(
          textContent,
          xsdElement.restrictions,
          line,
          column,
          xmlNode.name
        );
      }
    }
    validateRestrictions(value, restrictions, line, column, elementName) {
      for (const restriction of restrictions) {
        switch (restriction.type) {
          case "minLength":
            if (value.length < Number(restriction.value)) {
              this.addError(
                line,
                column,
                `Value '${value}' in element '${elementName}' is too short. Minimum length is ${restriction.value}`,
                "MIN_LENGTH_VIOLATION"
              );
            }
            break;
          case "maxLength":
            if (value.length > Number(restriction.value)) {
              this.addError(
                line,
                column,
                `Value '${value}' in element '${elementName}' is too long. Maximum length is ${restriction.value}`,
                "MAX_LENGTH_VIOLATION"
              );
            }
            break;
          case "pattern":
            const regex = new RegExp(String(restriction.value));
            if (!regex.test(value)) {
              this.addError(
                line,
                column,
                `Value '${value}' in element '${elementName}' does not match pattern '${restriction.value}'`,
                "PATTERN_VIOLATION"
              );
            }
            break;
          case "enumeration":
            break;
          case "minInclusive":
            if (Number(value) < Number(restriction.value)) {
              this.addError(
                line,
                column,
                `Value '${value}' in element '${elementName}' is below minimum ${restriction.value}`,
                "MIN_INCLUSIVE_VIOLATION"
              );
            }
            break;
          case "maxInclusive":
            if (Number(value) > Number(restriction.value)) {
              this.addError(
                line,
                column,
                `Value '${value}' in element '${elementName}' is above maximum ${restriction.value}`,
                "MAX_INCLUSIVE_VIOLATION"
              );
            }
            break;
        }
      }
    }
    validateSimpleValue(value, type) {
      switch (type) {
        case "string":
          return true;
        case "int":
        case "integer":
          return /^-?\d+$/.test(value);
        case "decimal":
        case "float":
        case "double":
          return /^-?\d*\.?\d+$/.test(value);
        case "boolean":
          return value === "true" || value === "false" || value === "1" || value === "0";
        case "date":
          return /^\d{4}-\d{2}-\d{2}$/.test(value);
        case "dateTime":
          return /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d+)?(Z|[+-]\d{2}:\d{2})?$/.test(
            value
          );
        case "time":
          return /^\d{2}:\d{2}:\d{2}(\.\d+)?(Z|[+-]\d{2}:\d{2})?$/.test(value);
        default:
          return true;
      }
    }
    isBuiltInType(type) {
      const builtInTypes = [
        "string",
        "int",
        "integer",
        "decimal",
        "float",
        "double",
        "boolean",
        "date",
        "dateTime",
        "time",
        "base64Binary",
        "hexBinary"
      ];
      return builtInTypes.includes(type);
    }
    addError(line, column, message, code) {
      this.errors.push({ line, column, message, code });
    }
  }
  class XsdToXmlGenerator {
    schema;
    options;
    errors = [];
    constructor(schema, options = {}) {
      this.schema = schema;
      this.options = {
        rootElement: options.rootElement ?? "",
        declaration: options.declaration ?? true,
        indent: options.indent ?? "  ",
        softUpperBound: options.softUpperBound ?? 3,
        genMode: options.genMode ?? "NORMAL",
        patternGenerators: options.patternGenerators ?? {},
        customValues: options.customValues ?? {},
        elementGenerators: options.elementGenerators ?? {},
        typeGenerators: options.typeGenerators ?? {}
      };
    }
    generate() {
      let xml = "";
      if (this.options.declaration) {
        xml += '<?xml version="1.0" encoding="UTF-8"?>\n';
      }
      const root = Object.entries(this.schema.elements)[0][1];
      xml += this.generateXml(root, "");
      return xml;
    }
    generateXml(element, parent) {
      const depth = (parent.match(/\//g) || []).length;
      if (element.minOccurs === 0 && this.options.genMode != "MAXIMAL") {
        return "";
      }
      let xml = "";
      const indent = this.options.indent.repeat(depth);
      const localType = this.getLocalType(element.type);
      const complexType = this.schema.complexTypes[localType];
      if (complexType) {
        xml += this.complexTypesGenerateXml(
          complexType,
          element.name,
          parent,
          depth
        );
        return xml;
      }
      const generatedValue = this.escapeXml(
        this.generateXmlValue(element.name, localType, parent)
      );
      xml += `${indent}<${element.name}>${generatedValue}</${element.name}>`;
      return xml;
    }
    generateXmlValue(elementName, localType, parent) {
      let generatedValue = this.customValue(elementName, parent);
      if (!generatedValue) {
        const func = this.options.elementGenerators[elementName];
        if (func) {
          generatedValue = func();
        }
      }
      if (!generatedValue) {
        const func = this.options.typeGenerators[localType];
        if (func) {
          generatedValue = func();
        }
      }
      if (!generatedValue) {
        if (this.isBuiltInType(localType)) {
          generatedValue = this.generateSimpleValue(localType);
        } else if (this.schema.simpleTypes[localType]) {
          generatedValue = this.simpleTypeGenXml(
            this.schema.simpleTypes[localType]
          );
        } else {
          generatedValue = `[TODO] ${elementName}, type=${localType}`;
        }
      }
      return generatedValue;
    }
    customValue(name, parent) {
      const xpath = parent + "/" + name;
      for (const [key, value] of Object.entries(this.options.customValues)) {
        if (xpath.endsWith(key)) {
          return value;
        }
      }
      return "";
    }
    choose(name, parent) {
      const xpath = parent + "/" + name;
      for (const key of Object.keys(this.options.customValues)) {
        if (xpath.endsWith(key)) {
          return true;
        }
        let lastIndex = key.length - 1;
        while (true) {
          let index = key.lastIndexOf("/", lastIndex);
          if (index === -1) {
            break;
          }
          let partial = key.substring(0, index);
          if (xpath.endsWith(partial)) {
            return true;
          }
          lastIndex = index - 1;
        }
      }
      return false;
    }
    complexTypesGenerateXml(complexType, elementName, parent, depth) {
      const indent = this.options.indent.repeat(depth);
      let xml = `${indent}<${elementName}`;
      const attributes = this.generateAttributes(complexType.attributes);
      if (attributes) {
        xml += " " + attributes;
      }
      if (depth === 0 && this.options.declaration && this.schema.targetNamespace) {
        xml = `${xml} xmlns="${this.schema.targetNamespace}"`;
      }
      const childBuffer = [];
      if (complexType.compositor === "choice") {
        let chosen;
        for (const child of complexType.elements) {
          if (this.choose(child.name, parent + "/" + elementName)) {
            chosen = child;
            break;
          }
          if (this.customValue(child.name, parent + "/" + elementName)) {
            chosen = child;
            break;
          }
        }
        if (!chosen) {
          chosen = complexType.elements[Math.floor(Math.random() * complexType.elements.length)];
        }
        childBuffer.push(this.generateXml(chosen, parent + "/" + elementName));
      } else if (complexType.compositor === "sequence") {
        for (const child of complexType.elements) {
          let loop = typeof child.maxOccurs === "number" ? child.maxOccurs : this.options.softUpperBound;
          while (loop > 0) {
            const xml2 = this.generateXml(child, parent + "/" + elementName);
            xml2 && childBuffer.push(xml2);
            loop--;
          }
        }
      } else {
        if (complexType.baseType) {
          childBuffer.push(this.generateXmlValue("", complexType.baseType, ""));
        }
      }
      if (childBuffer.length > 0) {
        xml += ">";
        xml += "\n" + childBuffer.join("\n");
        xml += `
${indent}</${elementName}>`;
      } else {
        xml += " />";
      }
      return xml;
    }
    patternCharsetMap(pattern) {
      const AZ = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
      const az = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".toLocaleLowerCase();
      const N9 = "0123456789";
      const AZN = AZ + N9;
      const AaN = AZ + az + N9;
      pattern = String(pattern);
      const index = pattern.indexOf("{");
      if (index !== -1) {
        pattern = pattern.substring(0, index);
      }
      switch (String(pattern)) {
        case "[A-Z0-9]":
          return AZN;
        case "[A-Za-z0-9]":
        case "[A-Z0-9a-z]":
          return AaN;
        default:
          return AaN;
      }
    }
    simpleTypeGenXml(simpleType) {
      const enumerations = simpleType.restrictions.filter((p) => p.type === "enumeration").map((e) => e.value);
      if (enumerations.length > 0) {
        return String(
          enumerations[Math.floor(Math.random() * enumerations.length)]
        );
      }
      let minLength = Number(
        simpleType.restrictions.find((p) => p.type === "minLength")?.value
      );
      let maxLength = Number(
        simpleType.restrictions.find((p) => p.type === "maxLength")?.value
      );
      switch (this.getLocalType(simpleType.baseType)) {
        case "string":
          const pattern = simpleType.restrictions.find((p) => p.type === "pattern")?.value || "";
          if (!minLength && !maxLength && pattern) {
            const matched = String(pattern).match(/\{(\d+),?(\d+)?\}/);
            if (matched) {
              if (matched[2]) {
                minLength = Number(matched[1]);
                maxLength = Number(matched[2]);
              } else {
                minLength = maxLength = Number(matched[1]);
              }
            }
          }
          if (!minLength) {
            return "";
          }
          const chars = this.patternCharsetMap(pattern);
          let cnt = maxLength === -1 ? 23 : Math.floor(Math.random() * (maxLength - minLength) + minLength);
          const buffer = [];
          while (cnt--) {
            buffer.push(chars[Math.floor(Math.random() * chars.length)]);
          }
          return buffer.join("");
        // "text-text-text";
        case "int":
        case "integer":
          return "9999999999999999";
        case "decimal":
        case "float":
        case "double":
          return "99999.01";
        case "boolean":
          return "true";
        case "date":
          return "2025-12-16";
        case "dateTime":
          return "2025-12-16T11:11:11.888";
        case "time":
          return "00:00:01Z";
        default:
          return `UNKNOWN baseType=${simpleType.baseType}`;
      }
    }
    generateAttributes(attributes) {
      const buffer = [];
      for (const xsdAttr of attributes) {
        if (xsdAttr.use === "required") {
          const localType = this.getLocalType(xsdAttr.type);
          const generatedValue = this.escapeXml(
            this.generateXmlValue("", localType, "")
          );
          buffer.push(`${xsdAttr.name}="${generatedValue}"`);
        }
      }
      return buffer.join(" ");
    }
    getLocalType(type) {
      const colonIndex = type.indexOf(":");
      return colonIndex === -1 ? type : type.substring(colonIndex + 1);
    }
    generateSimpleValue(type) {
      switch (type) {
        case "string":
          return "text-text-text";
        case "int":
        case "integer":
          return "9999999999999999";
        case "decimal":
        case "float":
        case "double":
          return "99999.01";
        case "boolean":
          return "true";
        case "date":
          return "2025-12-16";
        case "dateTime":
          return "2025-12-16T11:11:11.888";
        case "time":
          return "00:00:01Z";
        default:
          return `UNKNOWN type=${type}`;
      }
    }
    isBuiltInType(type) {
      const builtInTypes = [
        "string",
        "int",
        "integer",
        "decimal",
        "float",
        "double",
        "boolean",
        "date",
        "dateTime",
        "time",
        "base64Binary",
        "hexBinary"
      ];
      return builtInTypes.includes(this.getLocalType(type));
    }
    escapeXml(text) {
      if (typeof text !== "string") {
        return text;
      }
      return text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;");
    }
  }
  class XsdParser {
    xmlParser = new XmlParser();
    parseSchema(xsdString) {
      const { node, errors } = this.xmlParser.parse(xsdString);
      if (errors.length > 0 || !node) {
        return { schema: null, errors };
      }
      try {
        const schema = this.buildSchema(node);
        return { schema, errors: [] };
      } catch (error) {
        errors.push({
          line: 1,
          column: 1,
          message: error instanceof Error ? error.message : "Schema parsing error",
          code: "SCHEMA_ERROR"
        });
        return { schema: null, errors };
      }
    }
    buildSchema(schemaNode) {
      if (schemaNode.name !== "schema" && !schemaNode.name.endsWith(":schema")) {
        throw new Error("Root element must be schema");
      }
      const schema = {
        targetNamespace: schemaNode.attributes.targetNamespace,
        elements: {},
        complexTypes: {},
        simpleTypes: {},
        namespaces: {}
      };
      for (const [key, value] of Object.entries(schemaNode.attributes)) {
        if (key.startsWith("xmlns:")) {
          const prefix = key.substring(6);
          schema.namespaces[prefix] = value;
        } else if (key === "xmlns") {
          schema.namespaces[""] = value;
        }
      }
      for (const child of schemaNode.children) {
        const localName = this.getLocalName(child.name);
        switch (localName) {
          case "element":
            const element = this.parseElement(child);
            schema.elements[element.name] = element;
            break;
          case "complexType":
            const complexType = this.parseComplexType(child);
            schema.complexTypes[complexType.name] = complexType;
            break;
          case "simpleType":
            const simpleType = this.parseSimpleType(child);
            schema.simpleTypes[simpleType.name] = simpleType;
            break;
        }
      }
      return schema;
    }
    parseElement(elementNode) {
      const element = {
        name: elementNode.attributes.name || "",
        type: elementNode.attributes.type || "string",
        minOccurs: parseInt(elementNode.attributes.minOccurs || "1"),
        maxOccurs: elementNode.attributes.maxOccurs === "unbounded" ? "unbounded" : parseInt(elementNode.attributes.maxOccurs || "1"),
        attributes: [],
        children: [],
        namespace: elementNode.namespace
      };
      for (const child of elementNode.children) {
        const localName = this.getLocalName(child.name);
        switch (localName) {
          case "complexType":
            this.parseComplexType(child);
            element.type = `#inline-${element.name}`;
            break;
          case "simpleType":
            const simpleType = this.parseSimpleType(child);
            element.type = `#inline-${element.name}`;
            element.restrictions = simpleType.restrictions;
            break;
        }
      }
      return element;
    }
    parseComplexType(complexTypeNode) {
      const complexType = {
        name: complexTypeNode.attributes.name || "",
        compositor: "",
        elements: [],
        attributes: []
      };
      let children = complexTypeNode.children;
      if (children.length === 1 && this.getLocalName(children[0].children[0].name) === "choice") {
        children = children[0].children;
      }
      for (const child of children) {
        const localName = this.getLocalName(child.name);
        switch (localName) {
          case "sequence":
          case "choice":
          case "all":
            complexType.compositor = localName;
            for (const sequenceChild of child.children) {
              if (this.getLocalName(sequenceChild.name) === "element") {
                complexType.elements.push(this.parseElement(sequenceChild));
              }
            }
            break;
          case "attribute":
            complexType.attributes.push(this.parseAttribute(child));
            break;
          case "simpleContent":
            const baseType = child.children.find(
              (p) => this.getLocalName(p.name) === "extension"
            );
            const baseTypeAttributes = baseType?.children.find(
              (p) => this.getLocalName(p.name) === "attribute"
            );
            baseTypeAttributes && complexType.attributes.push(this.parseAttribute(baseTypeAttributes));
            complexType.baseType = baseType?.attributes.base;
            break;
        }
      }
      return complexType;
    }
    parseSimpleType(simpleTypeNode) {
      const simpleType = {
        name: simpleTypeNode.attributes.name || "",
        baseType: "string",
        restrictions: []
      };
      for (const child of simpleTypeNode.children) {
        const localName = this.getLocalName(child.name);
        if (localName === "restriction") {
          simpleType.baseType = child.attributes.base || "string";
          for (const restrictionChild of child.children) {
            const restrictionType = this.getLocalName(restrictionChild.name);
            const value = restrictionChild.attributes.value;
            if (value !== void 0) {
              const restriction = {
                type: restrictionType,
                value: isNaN(Number(value)) ? value : Number(value)
              };
              simpleType.restrictions.push(restriction);
            }
          }
        }
      }
      return simpleType;
    }
    parseAttribute(attributeNode) {
      return {
        name: attributeNode.attributes.name || "",
        type: attributeNode.attributes.type || "string",
        use: attributeNode.attributes.use || "optional",
        defaultValue: attributeNode.attributes.default,
        fixedValue: attributeNode.attributes.fixed
      };
    }
    getLocalName(name) {
      const colonIndex = name.indexOf(":");
      return colonIndex === -1 ? name : name.substring(colonIndex + 1);
    }
  }
  class XmlHelper {
    xmlParser = new XmlParser();
    xsdParser = new XsdParser();
    schema = null;
    validator = null;
    /**
     * Load and parse an XSD schema
     * @param xsdContent The XSD schema content as string
     * @returns Array of validation errors if any
     */
    loadSchema(xsdContent) {
      const { schema, errors } = this.xsdParser.parseSchema(xsdContent);
      if (schema && errors.length === 0) {
        this.schema = schema;
        this.validator = new XmlValidator(schema);
      }
      return errors;
    }
    /**
     * Validate XML against the loaded schema
     * @param xmlContent The XML content to validate
     * @returns Array of validation errors with line numbers
     */
    validateXml(xmlContent) {
      if (!this.schema || !this.validator) {
        return [
          {
            line: 1,
            column: 1,
            message: "No schema loaded. Call loadSchema() first.",
            code: "NO_SCHEMA"
          }
        ];
      }
      const { node, errors } = this.xmlParser.parse(xmlContent);
      if (errors.length > 0) {
        return errors;
      }
      if (!node) {
        return [
          {
            line: 1,
            column: 1,
            message: "Failed to parse XML",
            code: "PARSE_FAILED"
          }
        ];
      }
      const validationErrors = this.validator.validate(node);
      return validationErrors;
    }
    /**
     * Parse XML to JSON object
     * @param xmlContent The XML content to parse
     * @param options Options for XML to JSON conversion
     * @returns Parsed JSON object or null if parsing failed
     */
    xmlToJson(xmlContent, options) {
      const { node, errors } = this.xmlParser.parse(xmlContent);
      if (errors.length > 0 || !node) {
        return { success: false, errors };
      }
      try {
        const converter = new XmlToJsonConverter(options);
        const jsonData = converter.convert(node);
        return {
          success: true,
          data: jsonData,
          errors: []
        };
      } catch (error) {
        return {
          success: false,
          errors: [
            {
              line: 1,
              column: 1,
              message: error instanceof Error ? error.message : "Conversion error",
              code: "CONVERSION_ERROR"
            }
          ]
        };
      }
    }
    /**
     * Convert JSON object to XML string
     * @param jsonData The JSON data to convert
     * @param rootElement The root element name (optional)
     * @param options Options for JSON to XML conversion
     * @returns XML string representation
     */
    jsonToXml(jsonData, rootElement, options) {
      const converter = new JsonToXmlConverter(options);
      return converter.convert(jsonData, rootElement);
    }
    /**
     * Generate XML string from XSD Schema
     * @param options Options for XSD generate XML
     * @returns XML string representation
     */
    xsdGenXml(options) {
      if (!this.schema || !this.validator) {
        return [
          {
            line: 1,
            column: 1,
            message: "No schema loaded. Call loadSchema() first.",
            code: "NO_SCHEMA"
          }
        ];
      }
      const generator = new XsdToXmlGenerator(this.schema, options);
      return generator.generate();
    }
    /**
     * Parse XML without validation (schema-free parsing)
     * @param xmlContent The XML content to parse
     * @returns Parsed XML node structure
     */
    parseXml(xmlContent) {
      return this.xmlParser.parse(xmlContent);
    }
    /**
     * Get the currently loaded schema
     * @returns The loaded XSD schema or null
     */
    getSchema() {
      return this.schema;
    }
    /**
     * Check if a schema is currently loaded
     * @returns True if a schema is loaded
     */
    hasSchema() {
      return this.schema !== null;
    }
  }
  const XSD_ROOT = "conf/tfm";
  class FpsMessage {
    xmlHelper;
    constructor() {
      this.xmlHelper = new XmlHelper();
    }
    /**
     * Create Fps Message
     * @param service business service for load target messge xsd schema
     * @param options type - Message Type
     * @returns
     */
    create(service, options = {}) {
      {
        const { type = FpsMessageType.OUTWARD_REQUEST } = options;
        const serviceMessageMap = FPS_SERVICE_MESSAGE_MAP.get(service);
        const xsdFileanme = serviceMessageMap?.get(type);
        const xsdSchema = helpers.readFile(`${XSD_ROOT}/${xsdFileanme}.xsd`);
        this.xmlHelper.loadSchema(xsdSchema);
      }
      const xsdGenXmlOptions = {
        genMode: "NORMAL",
        // Consider alter element'minOccurs like `customValues`
        softUpperBound: 1,
        customValues: {
          "PtyId/PtyNm": "9927"
        },
        elementGenerators: {
          MsgId: function() {
            return "USTD-20251223-9480007";
          }
        },
        typeGenerators: {
          CountryCode: function() {
            return "CN";
          }
        }
      };
      const generatedXml = this.xmlHelper.xsdGenXml(xsdGenXmlOptions);
      return generatedXml + "";
    }
  }
  const fileCache = /* @__PURE__ */ new Map();
  class helpers {
    /**
     * Read file content
     * @param filename file path for read
     * @returns return the full file content
     */
    static readFile(filename) {
      if (!fileCache.has(filename)) {
        const file = node_fs.readFileSync(filename, { encoding: "utf8" });
        fileCache.set(filename, file);
      }
      return fileCache.get(filename) || "";
    }
  }
  exports2.FPS_SERVICE_C01_MESSAGE_TYPE_MAP = FPS_SERVICE_C01_MESSAGE_TYPE_MAP;
  exports2.FPS_SERVICE_MESSAGE_MAP = FPS_SERVICE_MESSAGE_MAP;
  exports2.FpsMessage = FpsMessage;
  exports2.FpsMessageType = FpsMessageType;
  exports2.FpsService = FpsService;
  exports2.fps = fps;
  exports2.helpers = helpers;
  exports2.person = person;
  Object.defineProperty(exports2, Symbol.toStringTag, { value: "Module" });
}));
